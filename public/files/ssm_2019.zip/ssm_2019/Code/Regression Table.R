#### 1. Load Files ####
rm(list=setdiff(ls(),"objs"))
load(paste0(objs$paths$data,"Weighted Regressions.Rdata"))

#### 2. Create Functions ####
make.decimal <- function(data) trimws(format(round(data, digits=3),scientific=F))
make.df <- function(modifier,model,labels,title){
	result <- summary(reg[[modifier]][[model]])[c(1,3,4)]
	names <- row.names(result)[grep("NEET_6MonthsYes",row.names(result))]
	result <- result[names,]
	names(result) <- c("b","lci","uci")
	result <- result %>% sapply(make.decimal) %>% 
		as.data.frame(stringsAsFactors=FALSE) %>%
		mutate(coef = paste0(b,"<br>[",lci,", ",uci,"]")) %>%
		dplyr::select(coef)
	labels <- labels %>%
		gsub("\n"," ",.) %>%
		paste("6+ Months NEET x",.)
	result$label <- c("6+ Months NEET",labels)
	names(result) <- c(title,"label")
	return(result)
}

#### 3. Basic Regression ####
results <- summary(reg$basic$full)["NEET_6MonthsYes",c(1,3,4)]
results <- results %>% sapply(make.decimal)
results <- paste0(results[1],"<br>[",results[2],", ",results[3],"]") %>%
	as.data.frame(stringsAsFactors=FALSE)
names(results) <- "Basic"
results$label <- "6+ Months NEET"


#### 4. Modifiers ####
for (modifier in objs$modifier.list){
	modifier.class <- objs$modifier.type[modifier]
	if (modifier.class=="factor"){
		model <- "lm.standard"
		labels <- objs$gg.info[[modifier]]$x.labels[-1]
		title <- objs$gg.info[[modifier]]$vname
	} else{
		model <- "lm.centered"
		labels <- objs$gg.info[[modifier]]$title
		title <- objs$gg.info[[modifier]]$title
	}
	result <- make.df(modifier,model,labels,title)
	results <- full_join(results,result,by="label")	
}
rnames <- results$label
results$label <- NULL
results <- mutate_each(results,funs(replace(., which(is.na(.)), "")))
row.names(results) <- rnames


#### 5. Make kable Table ####
reg.table <- knitr::kable(results,escape=FALSE,align='c') %>%
	kable_styling(bootstrap_options = "striped", full_width = FALSE,
					  font_size = 14)
save(reg.table,file=paste0(objs$paths$tables,
										"Regression Table.Rdata"))
