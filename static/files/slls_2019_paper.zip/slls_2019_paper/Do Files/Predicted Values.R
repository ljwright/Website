#### 1. Load Regression Results & Data ####
# rm(list=setdiff(ls(),"objs"))
load(paste0(objs$paths$data,"Weighted Regressions.Rdata"))
file <- paste0(objs$paths$data,
               list.files(path=objs$paths$data,
                          pattern="withweights.*Rdata"))
file <- file[which.max(file.info(file)$mtime)]
load(file)
rm(file,imp)

pred.vals <- list()
pred.names <- c("beta","se","lci","uci","evalue","pval","b")

#### 2. Basic ####
data <- imp.long[[1]]
lm <- reg$basic

sd <- sd(data$GHQ_W8_Likert)
preds <- data.frame(numeric(),numeric(),numeric(), numeric())
names(preds) <- pred.names[1:4]
for (model in names(lm)){
  row <- summary(lm[[model]])["NEET_6MonthsYes",-5]
  names(row) <- pred.names[1:4]
  dfree <- lm[[model]]$df["NEET_6MonthsYes"]
  evalue <- with(row,evalues.OLS(est=beta,se=se,sd=sd))[2,1]
  row <- cbind(model,row,dfree,evalue)
  preds <- rbind(preds,row)
}
preds$pval <- with(preds,2*pt(-abs(beta/se),dfree))
preds$b <- with(preds,beta/sd)
attr(preds,"ghq.sd") <- sd
pred.vals <- list(basic = preds)
rm(sd,preds,row,dfree,evalue,model)

#### 3. Temporary CI Function ####
temp.better.ci <- function(data,index=1:nrow(data),dfree){ 
  ci <- qt(0.975,df=dfree)
  data$lci[index] <- with(data,beta[index]-ci*se[index])
  data$uci[index] <- with(data,beta[index]+ci*se[index])
  data$pval[index] <- with(data,
                              2*pt(-abs(beta[index]/se[index]),df=dfree))
  return(data)
} ##### MIGHT NOT BE CORRECT!!!!

#### 3. Modifiers ####
for (modifier in objs$modifier.list){
  data <- imp.long[[modifier]]
  sd <- sd(data$GHQ_W8_Likert)  
  
  if (objs$modifier.type[modifier] == "factor"){
    # Factor
    levels <- levels(data[[modifier]])
    length <- length(levels)
    
    for (model in c("lm.all","lm.neet")){
      lm <- reg[[modifier]][[model]]
      
      
      preds <- summary(lm)[1:4]
      names(preds) <- pred.names[1:4]
      if (model=="lm.all") {
        rows <- grep("modifier",row.names(preds))
      } else if (model=="lm.neet") {
        rows <- grep("modifier.neet",row.names(preds))
      }
      preds <- preds[rows,]
      preds$pval <- with(preds,2*pt(-abs(beta/se),lm$df[rows]))
      if (model=="lm.all") preds <- rbind(c(0,0,0,0,NA),preds)
      
      
      preds$evalue <- 0
      for (i in 1:nrow(preds)){
        preds$evalue[i] <- with(preds[i,],evalues.OLS(est=beta,se=se,sd=sd))[2,1]
      }
      preds$b <- preds$beta/sd
      
      if (model=="lm.all") {
        preds$neet <-rep(c("Non-NEET","NEET"),c(length,length))
        preds$levels <- rep(levels,2)
        preds$comparator <- "0.NEET x 1.Modifier"
        pred.vals[[modifier]] <- preds
      } else if (model=="lm.neet") {
        preds$neet <-rep("NEET",length)
        preds$levels <- levels
        preds$comparator <- "0.NEET x i.Modifier"
        pred.vals[[modifier]] <- rbind(pred.vals[[modifier]],preds)
        
        coef <- coef(lm)[rows]
        vcov <- vcov(lm)[rows,rows]
        names(coef) <- levels
        dimnames(vcov) <- list(levels,levels)
        
        preds <- data.frame(
          neet = "NEET",
          levels = rep(levels[-length(levels)],(length-1):1),
          comparator = "1.NEET x j.Modifier",
          comparator.level = "",
          beta = 0, se = 0, lci = 0, uci = 0,
          evalue = 0, stringsAsFactors = FALSE
        )
        k <- 0
        for (i in 1:(length-1)){
          for (j in (i+1):length){
            k <- k+1
            preds$beta[k] <- coef[levels[i]] - coef[levels[j]]
            var <- vcov[levels[i],levels[i]] + vcov[levels[j],levels[j]] - 2*vcov[levels[i],levels[j]]
            preds$se[k] <- sqrt(var)
            
            preds$comparator.level[k] <- levels[j] 
            preds$evalue[k] <- with(preds[k,],evalues.OLS(est=beta,se=se,sd=sd))[2,1]
          }
        }
        preds <- temp.better.ci(preds,,attr(lm,"dfcom")) # NOT CORRECT:  TO ADD P VAL, LCI, UCI, DFREE - CORRECTLY. CHANGE TO BETTER.
        preds$b <- preds$beta/sd
        
        pred.vals[[modifier]] <- bind_rows(pred.vals[[modifier]],preds)
      }
    }  
  } else{
    # Continuous
    
    max <- max(data[[modifier]])
    quantiles <- quantile(imp.long[[modifier]][[modifier]],
                          c(0.1,0.25,0.75,0.9))
    mod.sd <- sd(imp.long[[modifier]][[modifier]])
    margins <- c(mod.sd,quantiles[3]-quantiles[2],quantiles[4]-quantiles[1])
    rm(quantiles,mod.sd)
    
    for (model in c("lm.all","lm.neet")){
      lm <- reg[[modifier]][[model]]
      
      if (model == "lm.all"){
        lin.com <- matrix(0,nrow=(2*max)+1,ncol=length(coef(lm)))
        dimnames(lin.com)[[2]] <- names(coef(lm))
        lin.com[1:max,"NEET_6MonthsNo:modifier"] <- 1:max
        lin.com[(0:max)+max+1,"NEET_6MonthsYes"] <- 1
        lin.com[(0:max)+max+1,"NEET_6MonthsYes:modifier"] <- 0:max
        preds <- summary(glht(lm,lin.com))$test[c("coefficients","sigma","pvalues")] %>%
          as.data.frame() %>% dplyr::select(coefficients,sigma) %>%
          rbind(c(0,0),.)
        names(preds) <- pred.names[1:2]
        preds$neet <-rep(c("Non-NEET","NEET"),c(max+1,max+1))
        preds$levels <- rep(0:max,2)
        preds$comparator <- "0.NEET x 0.Modifier"
        preds$b <- preds$beta/sd
        
        preds$uci <- NA
        preds$lci <- NA
        preds$pval <- NA
        preds <- temp.better.ci(preds,1:(max+1),lm$df["NEET_6MonthsNo:modifier"])
        preds <- temp.better.ci(preds,max+1+1:(max+1),attr(lm,"dfcom")) ## DEFINITELY NOT CORRECT - MOD=0, NEET=1 COULD BE IMPROVED.
        
        pred.vals[[modifier]] <- preds
        
      } else{
        lin.com <- matrix(0,nrow=max+4,ncol=length(coef(lm)))
        dimnames(lin.com)[[2]] <- names(coef(lm))
        lin.com[1:(max+1),"NEET_6MonthsYes"] <- 1
        lin.com[1:(max+1),"modifier:NEET_6MonthsYes"] <- 0:max
        lin.com[max+2:4,"modifier:NEET_6MonthsYes"] <- margins
        
        preds <- summary(glht(lm,lin.com))$test[c("coefficients","sigma","pvalues")] %>%
          as.data.frame() %>% dplyr::select(coefficients,sigma)
        names(preds) <- pred.names[1:2]
        
        preds$neet <-"NEET"
        preds$levels <- c(0:max,margins)
        preds$comparator <- c(rep("0.NEET x i.Modifier",max+1),
                              rep("1.NEET x j.Modifier",3))
        preds$b <- preds$beta/sd
        
        preds$uci <- NA
        preds$lci <- NA
        preds$pval <- NA
        preds <- temp.better.ci(preds,1,lm$df["NEET_6MonthsYes"])
        preds <- temp.better.ci(preds,2:(max+1),attr(lm,"dfcom")) # DEFINITELY NOT CORRECT - IN PRACTICE WITH M=50 OUT BY 0.8%; P VAL OUT BY <0.01%
        preds <- temp.better.ci(preds,max+2:4,lm$df["modifier:NEET_6MonthsYes"])
        
        pred.vals[[modifier]] <- bind_rows(pred.vals[[modifier]],preds)
      }
    }
  }
}
save(pred.vals,file=paste0(objs$paths$data,"Predicted Values.Rdata"))
rm(list=setdiff(ls(),"objs"))
