#### 1. Set mice Parameters ####
m <- 50
maxit <- 25
seed <- 1


#### 1. Import Dataset ####
dataset <- read_dta(paste0(objs$paths$data,"Dataset.dta"))
factors <- read_dta(paste0(objs$paths$data,"Factors.dta"))
for (variable in factors$name) {
  levels <- attr(dataset[[variable]],"labels")
  labels <- names(levels)
  dataset[variable] <- factor(dataset[[variable]],levels=levels,labels=labels)
  dataset[variable] <- droplevels(dataset[[variable]])
}
dataset <- dataset[dataset$Interviewed_W8=="Yes",]
class(dataset) <- "data.frame"
save(dataset,file=paste0(objs$paths$data,"Dataset.Rdata"))
rm(labels,levels,variable,factors)


#### 2. Keep Variables #####
df <- dplyr::select(dataset,NSID, GHQ_W8_Likert,NEET_6Months,
             !!objs$modifier.list,!!objs$covariates.list,
             Has_GHQ_W8,Survey_Weight_W8)


#### 5. Impute Missing Data including Interaction Terms ####
imp <- list()
imp.long <- list()
filepath <- paste0(objs$paths$data,"mice_tilling2016_withweights") %>%
  paste(m,seed,maxit,Sys.Date(),sep="_")
for (modifier in objs$modifier.list){
  
  df$modifier <- df[[modifier]]
  modifier.class <- class(df$modifier)
  
  #### a. Add Interaction Term #####
  if (modifier.class == "factor"){
    modifier.levels <- levels(df$modifier)
    
    exposure.modifier.text <- "factor((as.numeric(NEET_6Months)-1)*(as.numeric(modifier)-1))"
    outcome.modifier.text <-  paste0("ifelse(modifier==modifier.levels[",
                                     1:length(modifier.levels),
                                     "],GHQ_W8_Likert,0)")
    
  } else {
    exposure.modifier.text <- "(as.numeric(NEET_6Months)-1)*modifier"
    outcome.modifier.text <- "GHQ_W8_Likert*modifier"
    
  }
  outcome.exposure.text <- "GHQ_W8_Likert*(as.numeric(NEET_6Months)-1)"
  
  df$exposure.modifier <- with(df,eval(parse(text=exposure.modifier.text)))
  if (modifier.class == "factor" ){
    for (i in 1:length(modifier.levels)){
      colname <- paste0("outcome.modifier.",i)
      df[colname] <- with(df,eval(parse(text=outcome.modifier.text[i])))
    }
  } else{
    df$outcome.modifier <- with(df,eval(parse(text=outcome.modifier.text))) 
  }
  df$outcome.exposure <- with(df,eval(parse(text=outcome.exposure.text)))   
  
  
  #### b. mice Set-Up ####
  outcome.modifier <- names(df)[grep("outcome.modifier",names(df))]
  
  methods <- make.method(df)
  methods["exposure.modifier"] <- paste0("~I(", exposure.modifier.text, ")")
  methods[outcome.modifier] <- paste0("~I(", outcome.modifier.text, ")")
  methods["outcome.exposure"] <- paste0("~I(", outcome.exposure.text, ")")
  methods[modifier] <- ""
  
  predictors <- make.predictorMatrix(df)
  predictors["modifier",c("exposure.modifier",outcome.modifier)] <- 0
  predictors["NEET_6Months",c("exposure.modifier","outcome.exposure")] <- 0
  predictors["GHQ_W8_Likert",c(outcome.modifier,"outcome.exposure")] <- 0
  predictors[,"NSID"] <- 0
  predictors[,"Has_GHQ_W8"] <- 0
  predictors[,modifier] <- 0
  
  #### c. Run mice ####
  start <- Sys.time()
  imp[[modifier]] <- mice(df, m = m, meth = methods, pred = predictors,
                          print = FALSE, seed = seed, maxit = maxit)
  end <- Sys.time()
  print(c(start,end))
  
  imp.long[[modifier]] <- mice::complete(imp[[modifier]],"long")
  imp.long[[modifier]][[modifier]] <- imp.long[[modifier]][["modifier"]]
  imp.long[[modifier]][c("modifier",
                         "exposure.modifier",
                         outcome.modifier,
                         "outcome.exposure")] <- NULL
  
  df[c("modifier",
       "exposure.modifier",
       outcome.modifier,
       "outcome.exposure")] <- NULL
  
  save(imp,imp.long,file=paste0(filepath,".Rdata"))
}
warnings()
rm(list=setdiff(ls(),"objs"))
