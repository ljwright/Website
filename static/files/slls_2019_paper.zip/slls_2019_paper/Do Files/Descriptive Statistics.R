#### 1. Load Most Recent Imputation File ####
file <- paste0(objs$paths$data,
					list.files(path=objs$paths$data,
								  pattern="withweights.*Rdata"))
file <- file[which.max(file.info(file)$mtime)]
load(file)
for (modifier in objs$modifier.list){
	imp.long[[modifier]] <- imp.long[[modifier]][imp.long[[modifier]]$Has_GHQ_W8=="Yes",]
}
m <- imp[[1]]$m
rm(imp,modifier,file) ###! SHOULD HAVE THIS LOOP IN PLOTS TOO#


##### 2. Create Functions #####
pretty.n <- function(x) trimws(format(round(x, 0),big.mark=","))
pretty.prop <- function(x) trimws(format(round(x, 2), nsmall=2))


# library(httr)
# library(jsonlite)
# library(lubridate)
# library(tidyverse)
# library(zoo)
# library(stringi)


##### 3. Descriptive Statistics Table #####
df <- data.frame(
	variable = character(),levels = character(),
	neet = character(),not.neet = character(),
	stringsAsFactors = FALSE
)
for (modifier in objs$modifier.list){
	modifier.class <- objs$modifier.type[modifier]
	
	if (modifier.class == "factor"){
		levels <- levels(imp.long[[modifier]][[modifier]])
		length <- length(levels)
		n <- table(imp.long[[modifier]][[modifier]],
					  imp.long[[modifier]]$NEET_6Months)/m
		prop <- prop.table(n,margin=2)*100
		dstat <- data.frame(
			variable = objs$gg.info[[modifier]]$vname,
			levels = gsub("\n"," ",objs$gg.info[[modifier]]$x.labels),
			neet = paste0(pretty.n(n)[,2]," (",pretty.prop(prop)[,2],"%)"),
			not.neet = paste0(pretty.n(n)[,1]," (",pretty.prop(prop)[,1],"%)"),
			stringsAsFactors = FALSE
		)
		dstat$variable[-1] <- ""
		if (length==2) dstat <- dstat[2,]
	} else{
		descriptives <- by(imp.long[[modifier]][[modifier]],
								 imp.long[[modifier]]$NEET_6Months,
								 psych::describe) 
		dstat <- data.frame(
			variable = "",
			levels = objs$gg.info[[modifier]]$title,
			neet = paste0(pretty.prop(descriptives$Yes["mean"]),
							  " (",pretty.prop(descriptives$Yes["sd"]),")"),
			not.neet = paste0(pretty.prop(descriptives$No["mean"]),
							  " (",pretty.prop(descriptives$No["sd"]),")"),
			stringsAsFactors = FALSE
		)
	}
	df <- rbind(df,dstat)
}

descriptives<-knitr::kable(df,row.names = FALSE,align='rrcc',
									col.names = c("","Variable",
				 				  "6+ Months NEET","<6 Months NEET")) %>%
	kable_styling(bootstrap_options = "striped", full_width = FALSE,
					  font_size = 20)
descriptives
save(descriptives,file=paste0(objs$paths$tables,
										"Descriptive Statistics.Rdata"))


#### 3. Cohort Profile #### ## ADD CBBPALETTE TO OBJECTS.
path <- paste("dataset/LMS/timeseries/YBVQ/data")
raw <- GET(url = "https://api.ons.gov.uk",path = path)
df <- fromJSON(rawToChar(raw$content))$months[c("date","value")] %>%
	mutate(date=as.yearmon(date, "%Y %b"),
		   date=as.Date(date),
		   value=as.numeric(value)) %>%
	filter(date>=as.Date("2006-01-01"))
ggplot(df,aes(x=date,y=value))+
	annotate("rect", xmin=as.Date(c("2008-10-01","2015-08-01")), 
				xmax=as.Date(c("2010-05-01","2016-09-01")), 
				ymin=-Inf, ymax=Inf, alpha=0.5, fill="#CC79A7") +
	geom_vline(xintercept = as.Date(c("2006-07-01","2008-04-01","2009-06-30")),
				  linetype="dashed", color="#0072B2")+
	geom_line(color="#009E73",size=0.8)+
	annotate("text", x = as.Date(c("2006-07-01","2008-04-01","2009-06-30")),
				y=c(17,15,13),
				label=c("Left Compulsory\n Education",
			 		"Great Recession\n Starts",
			 		"Great Recession\n Ends"),size=4)+
	theme_minimal()+
	labs(x="",y="16-24 y.o. Unemployment Rate (%)")+
	scale_x_date(limits=as.Date(c("2006-01-01","2019-04-01")),
				 breaks = as.Date(c("2006-01-01","2010-01-01","2014-01-01","2018-01-01")),
				 labels = c("Jan 2006","Jan 2010","Jan 2014","Jan 2018"))+
	theme(axis.text.x = element_text(size=12,color="#000000"),
			axis.text.y = element_text(size=12,color="#000000"))
ggsave(paste0(objs$paths$images,"Cohort Profile.png"),
		 device="png", width = 10, height = 5, unit="in")
dev.off()

rm(list=setdiff(ls(),"objs"))

 