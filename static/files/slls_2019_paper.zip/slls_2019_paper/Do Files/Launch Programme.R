#### MICOMBINE AND POOL GIVE DIFFERENT DEGREES OF FREEDOM
#### NEED TO WORK OUT CORRECT DF FOR CONFIDENCE INTERVAL - CAN'T JUST USE MODEL DF
#### NEED TO WORK OUT HOW TO COMBINE DFs FOR CI OF LINEAR COMBINATION
#### NEET TO PUT IMPUTED DATA FILEPATH INTO LAUNCH PROGRAMMES.
#### 1. Set Up Workspace ####
setwd("E:/Next Steps 1-8")
rm(list=ls())

#### 2. Load Packages ####
library(haven)
library(tidyverse)
library(ggplot2)
library(mice)
library(mitools)
library(EValue)
library(multcomp)
library(httr)
library(jsonlite)
library(lubridate)
library(tidyverse)
library(zoo)
library(stringi)
library(kableExtra)
# library(psych)


#### 3. Clear Console ####
cat("\014")


#### 4. Create Objects ####
objs <- list(paths = list(data = "Data/SLLS 2019/", 
                          do = "Do Files/SLLS 2019/",
                          writing = "Writing/SLLS 2019/"),
             modifier.list = c("Female","Int_LOC_W2_Sum",
                               "UnemBad","IMD_W2",
                               "NSSEC5_W1"),
             covariates.list = c("GHQ_W2_Likert","GHQ_W4_Likert",
                                 "GenHealth_W2","HasDisability",
                                 "Ethnicity", "HH_EngLang_W1", "FamType_W1",
                                 "Education_W8", "Risk_W2", "SchoolAtt_W2"),
             gg.info = list(
               Female = list(x.labels = c("Male","Female"), title = "Male", 
               				  vname = "Gender"),
               Int_LOC_W2_Sum = list(x.title = "Internal Locus of Control",
                                     title = "Internal LOC",
                                     x.breaks = c(0,3,6,9)),
               UnemBad = list(x.labels = c("Job\nPreferable","Unemployment\nSometimes\nPreferable"), 
               			   title = "Employment Preference", 
               			   vname = "Employment Preference"),
               IMD_W2 = list(x.title = "Index of Multiple Deprivation",
                             title = "IMD",
                             x.breaks = c(0,25,50,75,86)),
               NSSEC5_W1 = list(x.labels=c("Higher","Intermediate",
                                           "Small\nEmployer","Lower\nSupervisory",
                                         "(Semi-)\nRoutine","Long-Term\nUnemployed"),
                                title = "Higher Class", vname = "Family NS-SEC"))
)
# objs$paths$imputed <- paste0(objs$paths$data,
#                              "mice_tilling2016_withweights_50_1_25_2019-08-29.Rdata")
objs$paths$images <- paste0(objs$paths$writing,"Images/")
objs$paths$tables <- paste0(objs$paths$writing,"Tables/")
factors <- read_dta(paste0(objs$paths$data,"Factors.dta"))
objs$modifier.type <- ifelse(objs$modifier.list %in% factors$name,"factor","numeric")
names(objs$modifier.type) <- objs$modifier.list
rm(factors)
