#### 1. Load Most Recent Imputation File ####
file <- paste0(objs$paths$data,
               list.files(path=objs$paths$data,
                          pattern="withweights.*Rdata"))
file <- file[which.max(file.info(file)$mtime)]
load(file)
for (modifier in objs$modifier.list){
  imp.long[[modifier]] <- imp.long[[modifier]][imp.long[[modifier]]$Has_GHQ_W8=="Yes",]
}
rm(imp,modifier)

#### 2. Create Regression Function ####
get.regression <- function(data,formula,...){
	result <- data %>% 
		by(factor(.$.imp),
		   function(x) lm(formula = formula,data=x,weights=Survey_Weight_W8)) %>%
		MIcombine()
	int <- data %>%
		by(factor(.$.imp),
		   function(x) lm(formula = formula,data=x,weights=Survey_Weight_W8)) %>%
		pool()
	df.names <- names(result$df)
	result$df <- int$pooled$df    # Using mice df formula.
	names(result$df) <- df.names
	attr(result,"dfcom") <- int$pooled$dfcom[1] 
	return(result)
}


#### 3. Set Up Initial Objects ####
reg <- list()
formula.basic <- as.formula(paste0("GHQ_W8_Likert ~ ",
                                   paste(c(objs$modifier.list,
                                           objs$covariates.list),collapse=" + ")))


#### 4. Basic Regressions ####d
data <- imp.long[[1]]
formula.full <- update(formula.basic,. ~. + NEET_6Months)

reg$basic <- list()
reg$basic$bivariate <- get.regression(data, 
                                      GHQ_W8_Likert ~ NEET_6Months)
reg$basic$withghq <- get.regression(data,
                                    GHQ_W8_Likert ~ NEET_6Months + GHQ_W2_Likert + GHQ_W4_Likert)
reg$basic$full <- get.regression(data,
                                 formula.full)	

rm(formula.full)


#### 4. Moderator Regressions ####
for (modifier in objs$modifier.list){
  data <- imp.long[[modifier]]
  data$modifier <- data[[modifier]]
  reg[[modifier]] <- list(modifier = modifier)
	
	if (class(data$modifier)=="factor"){
	# FACTOR
	 data$modifier.all <- with(data,
	                         interaction(NEET_6Months,
	                                     modifier,
	                                     lex.order=TRUE))     # i.NEET#i.Modifier
	 data$modifier.neet <- factor(data$modifier,
												levels=c(levels(data$modifier),
															"Not NEET")) %>%
										relevel("Not NEET") %>%
										replace(data$NEET_6Months=="No",
												  "Not NEET")                       # i.Modifier + i.NEET#i.Modifier
	
	formula.basic.nomod <-  update(formula.basic,
												 paste0("~ . -",modifier))
	formula.int.all <- update(formula.basic.nomod,
									  ~ . + modifier.all)                     # i.NEET#i.Modifier
	formula.int.neet <- update(formula.basic.nomod,
									  ~ . + modifier + modifier.neet)         # i.Modifier + i.NEET#i.Modifier
	formula.int.standard <- update(formula.basic.nomod,
							   ~ . + NEET_6Months*modifier)               # i.NEET##i.Modifier
	
	reg[[modifier]]$lm.all <- get.regression(data,formula.int.all)
	reg[[modifier]]$lm.neet <- get.regression(data,formula.int.neet)
	reg[[modifier]]$lm.standard <- get.regression(data,formula.int.standard)			
	} else{
	# CONTINUOUS
	formula.int.all <- update(formula.basic,
									  paste0(" ~ . - ",modifier,
									  		 "+ NEET_6Months + modifier:NEET_6Months")) # i.NEET + i.NEET#c.Modifier
	formula.int.neet <- update(formula.basic,
									  paste0(" ~ . - ",modifier,
									  		 "+ modifier*NEET_6Months"))      # i.NEET##c.Modifier
	
	reg[[modifier]]$lm.all <- get.regression(data,formula.int.all)
	reg[[modifier]]$lm.neet <- get.regression(data,formula.int.neet)
	
	data$modifier <- scale(data$modifier,scale=FALSE) ## ADDED FOR MEAN CENTRE - BUT CAN REMOVE.
	reg[[modifier]]$lm.centered <- get.regression(data,formula.int.neet)
	}
}
save(reg,file=paste0(objs$paths$data,"Weighted Regressions.Rdata"))
rm(list=setdiff(ls(),"objs"))


