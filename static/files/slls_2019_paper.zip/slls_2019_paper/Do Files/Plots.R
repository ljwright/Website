# SET COMMON CHART ELEMENTS AT THE TOP.
# MAYBE CHANGE TITLES TO SUBTITLES
# FOR FACTORS, CHANGE "0.NEET x 1.Modifier" to "0.NEET x 0.Modifier"
#### 1. Load Data and Make Functions ####
# rm(list=setdiff(ls(),"objs"))
load(paste0(objs$paths$data,"Predicted Values.Rdata"))
file <- paste0(objs$paths$data,
			   list.files(path=objs$paths$data,
			   		   pattern="withweights.*Rdata"))
file <- file[which.max(file.info(file)$mtime)]
load(file)
rm(file)

numeric.mod <- objs$modifier.list[objs$modifier.type == "numeric"]
quantiles <- list()
for (modifier in numeric.mod){
  data <- imp.long[[modifier]][[modifier]]
  quantiles[[modifier]] <- quantile(data,c(0.1,0.5,0.9))
}
data <- imp.long[[1]][1,]
rm(imp,imp.long,numeric.mod)


#### 2. Make Functions #### # ADD TO OBJS SO CAN USE IN DESCRIPTIVE STATISTICS TOO.
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
names(cbbPalette) <- c("black","l.orange","l.blue","green","yellow","d.blue","d.orange","pink")
make.comma <- function(data) trimws(format(round(data, digits=2),big.mark=",",scientific=F))
make.decimal <- function(data) trimws(format(round(data, digits=3),scientific=F))


#### 3. Basic Plot ####
preds <- pred.vals$basic # change to save in single results object
annotation <- paste0("p = ",make.decimal(preds$pval))
ggplot(preds,aes(x=model, y=beta, ymin=lci, ymax=uci, color=model)) +
	geom_hline(yintercept = 0) + geom_pointrange(shape=16,size=0.7) +
	theme_minimal() +  theme(legend.position = "none") +
  scale_color_manual(values = alpha(cbbPalette[c(6,7,4)])) +
  labs(title="Predicted Effect of 6+ Months NEET",x="",y="") + 
  scale_x_discrete(labels=c("bivariate" = "Bivariate",
                            "withghq" = "+ GHQ @ Age 14 & 16",
                            "full" = "+ Full Controls")) +
  annotate("text", x = (1:3)+0.05, y=preds$beta+0.05,
           label=annotation, hjust = 0) +
  theme(axis.text.x = element_text(size=12,color="#000000"),
        axis.text.y = element_text(size=12,color="#000000"))
ggsave(paste0(objs$paths$images,"Basic.png"),device="png", 
       width = 10, height = 5, unit="in")
while (!is.null(dev.list()))  dev.off()


#### 4. Moderator Plots ####
for (modifier in objs$modifier.list){
  modifier.class <- objs$modifier.type[modifier]
  preds <- pred.vals[[modifier]]
  
  ## Factor
  if (modifier.class == "factor"){
    levels <- levels(data[[modifier]])
    length <- length(levels)
    
    # All Effects
    p <- preds[preds$comparator=="0.NEET x 1.Modifier",] %>%
      mutate(n = factor(1:nrow(.)))
    title <- paste("Predicted Effect Relative to <6 Months NEET,",
                   objs$gg.info[[modifier]]$title)
    annotate.x <- c(0,length) + (1+length)/2
    annotate.y <- max(p$uci)+0.2
    color <- cbbPalette[7:6]
    ggplot(p,aes(x=n, y=beta, ymin=lci, ymax=uci, color=factor(neet,unique(neet)))) +
      geom_hline(yintercept = 0) + geom_pointrange(shape=16,size=0.7) +
      theme_minimal() +  theme(legend.position = "none") +
      scale_color_manual(values = alpha(color)) +
      labs(title=title,x="",y="") +
      scale_x_discrete(breaks = p$n,
                       labels=rep(objs$gg.info[[modifier]]$x.labels,2)) +
      theme(axis.text.x = element_text(size=11,color="#000000"),
            axis.text.y = element_text(size=11,color="#000000")) +
      annotate("text",x=annotate.x, y=annotate.y,color=color,
               label=c("<6 Months NEET","6+ Months NEET"),
               fontface=2,vjust=1)
    ggsave(paste0(objs$paths$images,modifier," vs 0NEET_1Modifier.png"),
           device="png", width = 10, height = 5, unit="in")
    while (!is.null(dev.list()))  dev.off()
    
    # NEET Effect
    p <- preds[preds$comparator=="0.NEET x i.Modifier",] %>%
      mutate(n = factor(1:nrow(.)))
    color <- cbbPalette[(9-length):8]
    annotate.lbl <- paste0("p = ",make.decimal(p$pval))
    ggplot(p,aes(x=n, y=beta, ymin=lci, ymax=uci, color=n)) +
      geom_hline(yintercept = 0) + geom_pointrange(shape=16,size=0.7) +
      theme_minimal() +  theme(legend.position = "none") +
      scale_color_manual(values = alpha(color)) +
      labs(title="Predicted Effect of 6+ Months NEET",x="",y="") +
      scale_x_discrete(breaks = p$n,
                       labels=objs$gg.info[[modifier]]$x.labels) +
      theme(axis.text.x = element_text(size=11.5,color="#000000"),
            axis.text.y = element_text(size=11.5,color="#000000")) +
      annotate("text",x=as.numeric(p$n)+0.02*length,y=p$beta+0.05,
               label=annotate.lbl,hjust = 0,vjust=0)
    ggsave(paste0(objs$paths$images,modifier," vs 0NEET_iModifier.png"),
           device="png", width = 10, height = 5, unit="in")
    while (!is.null(dev.list()))  dev.off()
    
    if (length == 2){
      # NEET Effect + Differences
      p <- preds[preds$comparator %in% 
                   c("0.NEET x i.Modifier",
                     "1.NEET x j.Modifier"),] %>%
        mutate(n = factor(1:nrow(.)))
      color <- cbbPalette[(8-length):8]
      annotate.lbl <- paste0("p = ",make.decimal(p$pval))
      x.labels <- c(objs$gg.info[[modifier]]$x.labels,"Difference")
      ggplot(p,aes(x=n, y=beta, ymin=lci, ymax=uci, color=n)) +
        geom_hline(yintercept = 0) + geom_pointrange(shape=16,size=0.7) +
        theme_minimal() +  theme(legend.position = "none") +
        scale_color_manual(values = alpha(color)) +
        scale_x_discrete(breaks = p$n,
                         labels=x.labels) +
        labs(title="Predicted Effect of 6+ Months NEET",x="",y="") +
        theme(axis.text.x = element_text(size=11.5,color="#000000"),
              axis.text.y = element_text(size=11.5,color="#000000")) +
        annotate("text",x=as.numeric(p$n)+0.02*(length+1),y=p$beta+0.05,
                 label=annotate.lbl,hjust = 0,vjust=0)
      ggsave(paste0(objs$paths$images,modifier," vs 0NEET_iModifier and 1NEET_jModifier.png"),
             device="png", width = 10, height = 5, unit="in")
      while (!is.null(dev.list()))  dev.off()
    } else{
      # Heat Map
      p <- preds[preds$comparator=="1.NEET x j.Modifier",] %>%
        mutate(n = factor(1:nrow(.)))  
      p$levels <- factor(p$levels,levels = levels)
      p$comparator.level <- factor(p$comparator.level,levels = rev(levels))  
      color <- cbbPalette[c(7,4)]
      annotate.x <- match(p$levels,levels)
      annotate.y <- match(p$comparator.level,levels[length:1])
      annotate.lbl <-  paste0(make.decimal(p$beta),"\n(p = ",make.decimal(p$pval),")")
      x.labels <- objs$gg.info[[modifier]]$x.labels[-length]
      y.labels <- rev(objs$gg.info[[modifier]]$x.labels)[-length]
      ggplot(p,aes(x=levels,y=comparator.level,fill=beta))+
        geom_raster() + theme_minimal() +
        labs(title="Difference in Effect of 6+ Months NEET (Column minus Row)",x="",y="")+
        scale_fill_gradientn(name="",colours=color) +
        annotate("text",x=annotate.x,y=annotate.y,
                 label=annotate.lbl,color="white") +
        theme(legend.justification=c(1,0),
              legend.position=c(1,0.6)) +
        scale_x_discrete(labels=x.labels) +
        scale_y_discrete(labels=y.labels) +
        theme(axis.text.x = element_text(size=11.5,color="#000000"),
              axis.text.y = element_text(size=11.5,color="#000000",hjust=0.5))
      ggsave(paste0(objs$paths$images,modifier," vs 1NEET_jModifier.png"),
             device="png", width = 10, height = 5, unit="in")
      while (!is.null(dev.list()))  dev.off()
    }  
  ## Continuous
  } else{
    x.breaks <- objs$gg.info[[modifier]]$x.breaks
    
    # All Effects
    p <- preds[preds$comparator=="0.NEET x 0.Modifier",]
    title <- paste("Predicted Effect Relative to <6 Months NEET,",
                   objs$gg.info[[modifier]]$title,"= 0")
    x.title <- objs$gg.info[[modifier]]$x.title
    color <- cbbPalette[6:7]
    color.lbl <- c("6+ Months NEET","<6 Months NEET")
    ggplot(p,aes(x=levels, y=beta, ymin=lci, ymax=uci, 
                 color=factor(neet), fill=factor(neet))) +
      geom_segment(aes(x=0,xend=max(p$levels),y=0,yend=0),colour="black") +
      geom_line(size=1) + geom_ribbon(alpha=0.15,colour = NA) +
      theme_minimal() + 
      theme(legend.justification=c(1,0), legend.position=c(0.9,0.7)) +
      labs(title=title,x=x.title,y="") +
      scale_x_continuous(breaks= x.breaks) +
      scale_fill_manual(name="",values = alpha(color),labels=color.lbl) +
      scale_color_manual(name="",values = alpha(color),labels=color.lbl) +
      theme(axis.text.x = element_text(size=12,color="#000000"),
            axis.text.y = element_text(size=12,color="#000000"),
            axis.title.x = element_text(size=12))
    ggsave(paste0(objs$paths$images,modifier," vs 0NEET_0Modifier.png"),
           device="png", width = 10, height = 5, unit="in")
    while (!is.null(dev.list()))  dev.off()
    
    # NEET Effect
    p <- preds[preds$comparator=="0.NEET x i.Modifier",]
    qtile <- quantiles[[modifier]]
    title <- "Predicted Effect of 6+ Months NEET"
    x.title <- objs$gg.info[[modifier]]$x.title
    color <- cbbPalette[c(4,6)]
    ggplot(p,aes(x=levels, y=beta, ymin=lci, ymax=uci, 
                 color=factor(neet), fill=factor(neet))) +
      geom_hline(yintercept = 0) + 
      geom_line(size=1) + geom_ribbon(alpha=0.15,colour = NA) +
      geom_vline(xintercept = qtile, 
                 linetype="dashed", color=color[2],size=0.75) +
      theme_minimal() + theme(legend.position = "none") +
      labs(title=title,x=x.title,y="") +
      scale_x_continuous(breaks= x.breaks) +
      scale_fill_manual(name="",values = alpha(color[1]),labels = color.lbl) +
      scale_color_manual(name="",values = alpha(color[1]),labels = color.lbl) +
      annotate("text", x = qtile, y=max(p$uci),label=names(qtile),
               fontface =2,hjust=-0.3,color=color[2]) +
    theme(axis.text.x = element_text(size=12,color="#000000"),
          axis.text.y = element_text(size=12,color="#000000"),
          axis.title.x = element_text(size=12))
    ggsave(paste0(objs$paths$images,modifier," vs 0NEET_iModifier.png"),
           device="png", width = 10, height = 5, unit="in")
    while (!is.null(dev.list()))  dev.off()
    
    # NEET Effect @ Percentiles
    p <- preds[preds$comparator=="1.NEET x j.Modifier",] %>%
      mutate(n = factor(1:nrow(.)))
    color <- cbbPalette[6:8]
    annotate.lbl <- paste0("p = ",make.decimal(p$pval[3]))
    x.labels <- c("+ 1SD","75th vs 25th","90th vs 10th")
    ggplot(p,aes(x=n, y=beta, ymin=lci, ymax=uci, color=n)) +
      geom_hline(yintercept = 0) + geom_pointrange(shape=16,size=0.7) +
      theme_minimal() +  theme(legend.position = "none") +
      scale_color_manual(values = alpha(color)) +
      scale_x_discrete(breaks = p$n,
                       labels=x.labels) +
      labs(title="Predicted Effect of 6+ Months NEET",x="",y="") +
      theme(axis.text.x = element_text(size=11.5,color="#000000"),
            axis.text.y = element_text(size=11.5,color="#000000")) +
      annotate("text",x=3.06,y=p$beta[3]+0.05,
               label=annotate.lbl,hjust = 0,vjust=0)
    ggsave(paste0(objs$paths$images,modifier," vs 1NEET_jModifier.png"),
           device="png", width = 10, height = 5, unit="in")
    while (!is.null(dev.list()))  dev.off()
  }
}

rm(list=setdiff(ls(),"objs"))
