#### 1. IMPORT REGRESSIONS ####
load(paste0(objs$paths$data,"Regressions.Rdata"))
formula <- models$formulas$all
formula.fixed <- update(formula,~ . -(1 |pidp) - (1 |hidp))
df <- models$all@frame
preds.list <- list()

#### 2. VARIABLES
unem.rates <- df$AvUnemRate_PostFTE_C %>%
  quantile(.,na.rm=TRUE) %>%
  .[c(2,4)] %>% c(0,.)
unem.levels <- 0:1
max <- max(df$`I(Age_Y_C2^1)`)
ages <- 0:max 
names <- fixef(models$all) %>% names()
names(unem.rates)[1] <- "Mean"


#### 3. PREDICTED VALUES ####
# A. SET UP MATRIX AT COLUMN MEANS, EXCEPT BIRTH YEAR.
newdata <- df %>% 
  model.matrix(formula.fixed,.) %>%
  colMeans() %>% rep(.,max+1) %>%
  matrix(nrow=max+1,byrow=TRUE)
dimnames(newdata)[[2]] <- names
for (i in c("Unem_6MonthsYes",
            "AvUnemRate_PostFTE",
            "Age_Y_C2")){
  newdata[,grep(i,names)] <- 1
}
newdata[,grep("Birth_Y_C",names)] <- 0

# B. DATA FRAME FOR PREDICTED VALUES
pred <- data.frame(
  coefficients = numeric(),
  sigma = numeric(),
  lci = numeric(),
  uci = numeric(),
  age = numeric(),
  unem.level = numeric(),
  unem.rate = numeric()
)

# C. GET PREDICTED VALUES
for (unem.level in unem.levels){
  for (unem.rate in unem.rates){
    lin.com <- newdata
    
    for (i in 1:3) {
      g <- paste0("I(Age_Y_C2^",i,")")
      cols <- stri_detect_fixed(names, g)
      lin.com[,cols] <- lin.com[,cols]*(ages^i)
    }
    lin.com[,grep("Unem_6MonthsYes",names)] <- lin.com[,grep("Unem_6MonthsYes",names)]*unem.level
    lin.com[,grep("AvUnemRate_PostFTE",names)] <- lin.com[,grep("AvUnemRate_PostFTE",names)]*unem.rate
    
    preds <- summary(glht(models$all,lin.com))$test[c("coefficients","sigma","pvalues")] %>%
      as.data.frame() %>% dplyr::select(coefficients,sigma)
    preds$lci <- preds$coefficients - 1.96*preds$sigma
    preds$uci <- preds$coefficients + 1.96*preds$sigma
    preds$age <- 0:max
    preds$unem.level <- unem.level
    preds$unem.rate <- unem.rate
    
    preds$unem.rate.label <- names(unem.rates)[match(unem.rate,unem.rates)]
    preds$unem.level.label <- levels(df$Unem_6Months)[match(unem.level,unem.levels)]
    
    pred <- rbind(pred,preds)
  }
}
pred$interaction <- interaction(pred$unem.level.label,pred$unem.rate.label)
preds.list$predicted <- pred


#### 4. MARGINAL EFFECTS ####
# A. SET UP MATRIX AT VARIABLES=0
newdata <- matrix(0,nrow=max+1,ncol=length(names))
dimnames(newdata)[[2]] <- names
newdata[,grep("Unem_6MonthsYes",names)] <- 1

# B. DATA FRAME FOR PREDICTED VALUES
pred <- data.frame(
  coefficients = numeric(),
  sigma = numeric(),
  lci = numeric(),
  uci = numeric(),
  age = numeric(),
  unem.level = numeric(),
  unem.rate = numeric()
)

# C. GET PREDICTED VALUES
for (unem.rate in unem.rates){
  lin.com <- newdata
  
  for (i in 1:3) {
    g <- paste0("I(Age_Y_C2^",i,")")
    cols <- stri_detect_fixed(names, g)
    lin.com[,cols] <- lin.com[,cols]*(ages^i)
  }
  lin.com[,grep("AvUnemRate_PostFTE",names)] <- lin.com[,grep("AvUnemRate_PostFTE",names)]*unem.rate
  
  preds <- summary(glht(models$all,lin.com))$test[c("coefficients","sigma","pvalues")] %>%
    as.data.frame() %>% dplyr::select(coefficients,sigma)
  preds$lci <- preds$coefficients - 1.96*preds$sigma
  preds$uci <- preds$coefficients + 1.96*preds$sigma
  preds$age <- 0:max
  preds$unem.rate <- unem.rate
  
  preds$unem.rate.label <- names(unem.rates)[match(unem.rate,unem.rates)]
  
  pred <- rbind(pred,preds)
}
preds.list$marginal <- pred


#### 5. SAVE ####
save(preds.list,file=paste0(objs$paths$data,"Predicted Values.Rdata"))
rm(list=setdiff(ls(),"objs"))
