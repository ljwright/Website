#### 1. Set Up Workspace ####
setwd("E:/UKHLS 1-8 & BHPS 1-18, Special Licence/")
rm(list=ls())

#### 2. Load Packages ####
library(haven)
library(tidyverse)
library(ggplot2)
library(httr)
library(jsonlite)
library(lubridate)
library(tidyverse)
library(zoo)
library(stringi)
library(lme4)
library(multcomp)
# library(optimx)
# library(merTools)
# library(psych)


#### 3. Clear Console ####
cat("\014")


#### 4. Create Objects ####
objs <- list(paths = list(data = "Data/SLLS 2019/", 
                          do = "Do Files/SLLS 2019/",
                          writing = "Writing/SLLS 2019/"))


############################################################################
# NOTES
  # REMOVED LAD, PERIOD, AND COHORT GROUP RANDOM EFFECTS 
    # EXPLAIN SMALL PROPORTION OF RANDOM VARIANCE IN BELL 2014

# TO DO
  # RESCALE VARIABLES
  # CREATE GRAPHS
  # TURN PREDICTED VALUES INTO LOOP - MARGINAL AND PREDICTED SHARE CODE

# OFFCUTS
# models$all <- lmer(formula,df,control = lmerControl(optimizer ="Nelder_Mead")) %>% summary()
# models$all <- lmer(formula,df,
#                    control = lmerControl(optimizer ='optimx',
#                                          optCtrl=list(method='nlminb'))) %>% summary()