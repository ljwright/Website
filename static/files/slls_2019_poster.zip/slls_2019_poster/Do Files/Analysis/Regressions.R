#### 1. READ IN DATA ####
df <- read_dta(paste0(objs$paths$data,
                      "Collected Variables.dta"))
for (var in names(df)){
  if (!is.null(attr(df[[var]],"labels"))){
    levels <- attr(df[[var]],"labels")
    labels <- names(levels)
    df[[var]] <- factor(df[[var]],levels,labels)
  }
}
df$LAD_Code_2011 <- as.numeric(df$LAD_Code_2011)
rm(labels,levels,var)


#### 2. SET MODEL FORMULA ####
formula <- formula(GHQ_Likert ~ 1
                   + I(Age_Y_C2^1) + I(Age_Y_C2^2) + I(Age_Y_C2^3)
                   + Birth_Y_C + I(Birth_Y_C^2) + Birth_Y_Indicator:I(Birth_Y_C^2)
                   + Birth_Y_C:I(Age_Y_C2^1)
                   + Unem_6Months
                   + Unem_6Months:I(Age_Y_C2^1)
                   + AvUnemRate_PostFTE_C
                   + AvUnemRate_PostFTE_C:I(Age_Y_C2^1)
                   + Unem_6Months:AvUnemRate_PostFTE_C
                   + Unem_6Months:AvUnemRate_PostFTE_C:I(Age_Y_C2^1)
                   + Female + Ethnicity + FatherWorking_Age14 + HiQual_Last
                   + (1 |pidp) + (1 |hidp))
# formula.fixed <- update(formula,~ . -(1 |pidp) - (1 |hidp))

#### 2. RUN MODELS ####
models <- list()
models$all <- lmer(formula,df)
models$formulas$all <- formula
# models$male <- lmer(update(formula,~.-Female),
#                     df[df$Female=="No",]) %>% summary()
# models$female <- lmer(update(formula,~.-Female),
#                       df[df$Female=="Yes",]) %>% summary()
save(models,file=paste0(objs$paths$data,"Regressions.Rdata"))
rm(list=setdiff(ls(),"objs"))
