#### 1. IMPORT REGRESSIONS ####
load(paste0(objs$paths$data,"Predicted Values.Rdata"))


#### 2. COMMON CHART ELEMENTS
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
x.breaks <- c(0,((1:4)*10)+2)

#### 2. MAIN EFFECTS ####
p <- preds.list$predicted
p <- p[p$unem.rate.label=="Mean",]
color <- rep(cbbPalette[c(6,7)],2)
color.labels <- c("<6 Months Youth Unemployment","6+ Months Youth Unemployment")
facet.labels <- c(`25%`="25th Percentile UK Unemployment Rate",
                  `75%` = "75th Percentile UK Unemployment Rate")

ggplot(p,aes(x=age, y=coefficients, ymin=lci, ymax=uci, 
             color=unem.level.label, fill=unem.level.label)) +
  geom_line(size=1) + geom_ribbon(alpha=0.15,colour = NA) +
  theme_minimal() + labs(x="Age",y="Predicted GHQ",
                         fill="",color="") +
  scale_x_continuous(breaks=x.breaks,labels=x.breaks+18,
                     limits=c(0,42),minor_breaks = NULL)+ 
  scale_color_manual(values = alpha(color),labels=color.labels) +
  scale_fill_manual(values = alpha(color),labels=color.labels) +
  theme(legend.position="bottom")+
  theme(plot.title = element_text(size=36),
        axis.text.x = element_text(size=32,color="#000000"),
        axis.text.y = element_text(size=32,color="#000000"),
        axis.title.x = element_text(size=32),
        axis.title.y = element_text(size=32),
        legend.text=element_text(size=32))
ggsave(paste0(objs$paths$writing,"Images/Main Predicted Values.png"),
       device="png", width = 20, height = 12, unit="in")
while (!is.null(dev.list()))  dev.off()


#### 3. PREDICTED EFFECTS BY UNEMPLOYMENT RATE ####
p <- preds.list$predicted
p <- p[p$unem.rate.label!="Mean",]
color <- rep(cbbPalette[c(6,7)],2)
# title <- "Predicted GHQ Scores by Youth Unemployment Experience and Unemployment Rate"
x.breaks <- c(0,((1:4)*10)+2)
color.labels <- c("<6 Months Youth Unemployment","6+ Months Youth Unemployment")
facet.labels <- c(`25%`="25th Percentile UK Unemployment Rate",
                  `75%` = "75th Percentile UK Unemployment Rate")
strip.color <- alpha(cbbPalette[4],0.3)

ggplot(p,aes(x=age, y=coefficients, ymin=lci, ymax=uci, 
                                        color=unem.level.label, fill=unem.level.label)) +
  geom_line(size=1) + geom_ribbon(alpha=0.15,colour = NA) +
  theme_minimal() + labs(x="Age",y="GHQ",
                         fill="",color="") +
  scale_x_continuous(breaks=x.breaks,labels=x.breaks+18,
                     limits=c(0,42),minor_breaks = NULL)+ 
  facet_grid(.~unem.rate.label,
             labeller=labeller(unem.rate.label=facet.labels)) +
  scale_color_manual(values = alpha(color),labels=color.labels) +
  scale_fill_manual(values = alpha(color),labels=color.labels) +
  theme(legend.position="bottom")+
  theme(plot.title = element_text(size=36),
        axis.text.x = element_text(size=32,color="#000000"),
        axis.text.y = element_text(size=32,color="#000000"),
        axis.title.x = element_text(size=32),
        axis.title.y = element_text(size=32),
        legend.text=element_text(size=32),
        strip.text.x = element_text(size = 32),
        strip.background = element_rect(color=strip.color,fill=strip.color))
ggsave(paste0(objs$paths$writing,"Images/Predicted Values.png"),
       device="png", width = 30, height = 10, unit="in")
while (!is.null(dev.list()))  dev.off()


#### 3. MARGINAL EFFECTS BY UNEMPLOYMENT RATE ####
p <- preds.list$marginal
p <- p[p$unem.rate.label!="Mean",]
color <- cbbPalette[c(4,8)]
title <- "Marginal Effect of 6+ Youth Unemployment Experience by Unemployment Rate"
x.breaks <- c(0,((1:4)*10)+2)
color.labels <- c("25th Percentile UK Unemployment Rate",
                  "75th Percentile UK Unemployment Rate")

ggplot(p,aes(x=age, y=coefficients, ymin=lci, ymax=uci, 
             color=unem.rate.label, fill=unem.rate.label)) +
  geom_segment(aes(x=0,xend=max(p$age),y=0,yend=0),colour="black") +
  geom_line(size=1) + geom_ribbon(alpha=0.15,colour = NA) +
  theme_minimal() + labs(x="Age",y="Difference in GHQ",
                         fill="",color="") +
  scale_x_continuous(breaks=x.breaks,labels=x.breaks+18,
                     limits=c(0,42),minor_breaks = NULL) +
  scale_color_manual(values = alpha(color),labels=color.labels) +
  scale_fill_manual(values = alpha(color),labels=color.labels) +
  theme(legend.position="bottom")+
  theme(axis.text.x = element_text(size=32,color="#000000"),
        axis.text.y = element_text(size=32,color="#000000"),
        axis.title.x = element_text(size=32),
        axis.title.y = element_text(size=32),
        legend.text=element_text(size=32))
ggsave(paste0(objs$paths$writing,"Images/Marginal Effects.png"),
       device="png", width = 20, height = 12, unit="in")
while (!is.null(dev.list()))  dev.off()




rm(list=setdiff(ls(),"objs"))