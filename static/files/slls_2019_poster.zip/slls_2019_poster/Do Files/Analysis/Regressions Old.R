#### 1. READ IN DATA ####
df <- read_dta(paste0(objs$paths$data,
                      "Collected Variables.dta"))
for (var in names(df)){
  if (!is.null(attr(df[[var]],"labels"))){
    levels <- attr(df[[var]],"labels")
    labels <- names(levels)
    df[[var]] <- factor(df[[var]],levels,labels)
  }
}
df$LAD_Code_2011 <- as.numeric(df$LAD_Code_2011)
rm(labels,levels,var)


#### 2. SET MODEL FORMULA ####
formula <- formula(GHQ_Likert ~ 1
                   + I(Age_Y_C2^1) + I(Age_Y_C2^2) + I(Age_Y_C2^3)
                   + Birth_Y_C + I(Birth_Y_C^2) + Birth_Y_Indicator:I(Birth_Y_C^2)
                   + Birth_Y_C:I(Age_Y_C2^1)
                   + Unem_6Months
                   + Unem_6Months:I(Age_Y_C2^1)
                   + AvUnemRate_PostFTE_C
                   + AvUnemRate_PostFTE_C:I(Age_Y_C2^1)
                   + Unem_6Months:AvUnemRate_PostFTE_C
                   + Unem_6Months:AvUnemRate_PostFTE_C:I(Age_Y_C2^1)
                   + Female + Ethnicity + FatherWorking_Age14 + HiQual_Last
                   + (1 |pidp) + (1 |hidp))
formula.fixed <- update(formula,~ . -(1 |pidp) - (1 |hidp))

#### 2. RUN MODELS ####
models <- list()
models$all <- lmer(formula,df)
# models$male <- lmer(update(formula,~.-Female),
#                     df[df$Female=="No",]) %>% summary()
# models$female <- lmer(update(formula,~.-Female),
#                       df[df$Female=="Yes",]) %>% summary()



#### 3. GET PREDICTED VALUES ####
max <- max(df$Age_Y_C2)
quantile <- quantile(df$AvUnemRate_PostFTE_C,na.rm=TRUE)
names <- fixef(models$all) %>% names()
unem.rate <- quantile(df$AvUnemRate_PostFTE,na.rm=TRUE)[c(2,4)] %>% 
  round(.,2) %>% paste0(c("25th","75th")," Percentile (",.,"%)")
pred <- list()

# Change by Age
unem.rates <- df$AvUnemRate_PostFTE %>%
  quantile(.,na.rm=TRUE) %>%
  .[c(2,4)] %>% c(0,.)
ages <- 0:max 
unem.levels <- 0:1

lin.com <- model.matrix(formula.fixed,df)[1:((2*max)+1),]

unem.rate <- unem.rates[1]
unem.level <- unem.levels[2]









lin.com <- model.matrix(formula.fixed,df)[1:(max+1),]
lin.com[,] <- 0

for (i in c("Unem_6MonthsYes",
            "AvUnemRate_PostFTE",
            "Age_Y_C2")){
  lin.com[,grep(i,names)] <- 1
}
for (i in 1:3) {
  g <- paste0("I(Age_Y_C2^",i,")")
  cols <- stri_detect_fixed(names, g)
  lin.com[,cols] <- lin.com[,cols]*ages^i
}
lin.com[,grep("Unem_6MonthsYes",names)] <- lin.com[,grep("Unem_6MonthsYes",names)]*unem.level
lin.com[,grep("AvUnemRate_PostFTE",names)] <- lin.com[,grep("AvUnemRate_PostFTE",names)]*unem.rate
lin.com[,grep("Birth_Y_C",names)] <- 0
lin.com[,"(Intercept)"] <- 1



lin.com[,grep("Age_Y_C2",names)] <- ages
lin.com[,grep("Age_Y_C2",names)] <- ages
lin.com[,grep("Age_Y_C2",names)] <- ages
lin.com[,"I(Age_Y_C2^2)"] <- ages^2
lin.com[,"I(Age_Y_C2^3)"] <- ages^3

get.preds <- function(unem.rate,unem.level){
  
} 


# Set Up Matrix
unem.rates <- df$AvUnemRate_PostFTE_C %>%
  quantile(.,na.rm=TRUE) %>%
  .[c(2,4)] %>% c(0,.)
unem.levels <- 0:1
max <- max(df$Age_Y_C2)
ages <- 0:max 

names <- fixef(models$all) %>% names()
newdata <- models$all@frame %>% 
  model.matrix(formula.fixed,.) %>%
  colMeans() %>% rep(.,max+1) %>%
  matrix(nrow=max+1,byrow=TRUE)
dimnames(newdata)[[2]] <- names
for (i in c("Unem_6MonthsYes",
            "AvUnemRate_PostFTE",
            "Age_Y_C2")){
  newdata[,grep(i,names)] <- 1
}
newdata[,grep("Birth_Y_C",names)] <- 0

pred <- data.frame(
  coefficients = numeric(),
  sigma = numeric(),
  lci = numeric(),
  uci = numeric(),
  age = numeric(),
  unem.level = numeric(),
  unem.rate = numeric()
)


for (unem.level in unem.levels){
  for (unem.rate in unem.rates){
    lin.com <- newdata
    
    for (i in 1:3) {
      g <- paste0("I(Age_Y_C2^",i,")")
      cols <- stri_detect_fixed(names, g)
      lin.com[,cols] <- lin.com[,cols]*(ages^i)
    }
    lin.com[,grep("Unem_6MonthsYes",names)] <- lin.com[,grep("Unem_6MonthsYes",names)]*unem.level
    lin.com[,grep("AvUnemRate_PostFTE",names)] <- lin.com[,grep("AvUnemRate_PostFTE",names)]*unem.rate
    
    preds <- summary(glht(models$all,lin.com))$test[c("coefficients","sigma","pvalues")] %>%
      as.data.frame() %>% dplyr::select(coefficients,sigma)
    preds$lci <- preds$coefficients - 1.96*preds$sigma
    preds$uci <- preds$coefficients + 1.96*preds$sigma
    preds$age <- 0:max
    preds$unem.level <- unem.level
    preds$unem.rate <- unem.rate
    
    preds$unem.rate.label <- names(unem.rates)[match(unem.rate,unem.rates)]
    preds$unem.level.label <- levels(df$Unem_6Months)[match(unem.level,unem.levels)]
    
    pred <- rbind(pred,preds)
  }
}
pred$interaction <- interaction(pred$unem.level.label,pred$unem.rate.label)
ggplot(pred[pred$unem.rate.label=="",],aes(x=age, y=coefficients, ymin=lci, ymax=uci, 
             color=interaction, fill=interaction)) +
  geom_line(size=1) + geom_ribbon(alpha=0.15,colour = NA)




preds <- summary(glht(models$all,lin.com))$test[c("coefficients","sigma","pvalues")] %>%
  as.data.frame() %>% dplyr::select(coefficients,sigma)
preds$lci <- preds$coefficients - 1.96*preds$sigma
preds$uci <- preds$coefficients + 1.96*preds$sigma
preds$age <- 0:max

p <- preds
ggplot(p,aes(x=age, y=coefficients, ymin=lci, ymax=uci)) +
  geom_line(size=1) + geom_ribbon(alpha=0.15,colour = NA)




preds$comparison <- rep(c("<6 Months",
                          "6+ Months"),each=max+1)



colMeans(x, na.rm = FALSE, dims = 1)





  c(0,quantile(df$AvUnemRate_PostFTE,na.rm=TRUE)[c(2,4)]



ages <- c(1:max,0:max)
lin.com <- model.matrix(formula.fixed,df)[1:((2*max)+1),]
lin.com[,] <- 0
lin.com[,"Age_Y_C2"] <- ages
lin.com[,"I(Age_Y_C2^2)"] <- ages^2
lin.com[,"I(Age_Y_C2^3)"] <- ages^3
lin.com[-(1:max),"Unem_6MonthsYes"] <- 1
lin.com[-(1:max),"Age_Y_C2:Unem_6MonthsYes"] <- (0:max)

preds <- summary(glht(models$all,lin.com))$test[c("coefficients","sigma","pvalues")] %>%
  as.data.frame() %>% dplyr::select(coefficients,sigma) %>%
  rbind(c(0,0),.)
preds$lci <- preds$coefficients - 1.96*preds$sigma
preds$uci <- preds$coefficients + 1.96*preds$sigma
preds$age <- rep(0:max,2)
preds$comparison <- rep(c("<6 Months",
                          "6+ Months"),each=max+1)
pred$age <- preds

# Change by Unemployment Rate
ages <- rep(0:max,2)
lin.com <- model.matrix(formula.fixed,df)[1:((max+1)*2),]
lin.com[,] <- 0
lin.com[,grep("Unem_6MonthsYes",names)] <- 1
lin.com[,grep("Age_Y_C2",names)] <- lin.com[,grep("Age_Y_C2",names)]*ages
lin.com[,grep("AvUnemRate_PostFTE_C",names)] <- lin.com[,grep("AvUnemRate_PostFTE_C",names)]*rep(quantile[c("25%","75%")],each=max+1)

preds <- summary(glht(models$all,lin.com))$test[c("coefficients","sigma","pvalues")] %>%
  as.data.frame() %>% dplyr::select(coefficients,sigma)
preds$lci <- preds$coefficients - 1.96*preds$sigma
preds$uci <- preds$coefficients + 1.96*preds$sigma
preds$age <- rep(0:max,2)
preds$comparison <- rep(unem.rate,each=max+1)
pred$unem.rate <- preds


#### 4. MAKE PLOTS ####
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
names(cbbPalette) <- c("black","l.orange","l.blue","green","yellow","d.blue","d.orange","pink")
x.breaks <- c(0,((1:4)*10)+2)
x.labels <- x.breaks+18


# Change by Age
p <- pred
color <- cbbPalette[c(6,7)]
title <- "Predicted Effects, Relative to <6 Months Youth Unemployment, Age 18"
title.color <- "Youth Unemployment"
filename <- "Images/Age.png"

ggplot(p[p$unem.rate.label=="75%",],aes(x=age, y=coefficients, ymin=lci, ymax=uci, 
             color=interaction, fill=interaction)) +
  geom_line(size=1) + geom_ribbon(alpha=0.15,colour = NA) +
  theme_minimal() + labs(title=title,x="Age",y="GHQ",
                         fill=title.color,color=title.color) +
  scale_x_continuous(breaks=x.breaks,labels=x.breaks+18,limits=c(0,42)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
  scale_fill_manual(values = alpha(color)) +
  scale_color_manual(values = alpha(color)) +
  theme(axis.text.x = element_text(size=12,color="#000000"),
        axis.text.y = element_text(size=12,color="#000000"),
        axis.title.x = element_text(size=12))
ggsave(paste0(objs$paths$writing,"Images/Age.png"),
       device="png", width = 10, height = 5, unit="in")
while (!is.null(dev.list()))  dev.off()


# Change by Unemployment Rate
p <- pred$unem.rate
color <- cbbPalette[c(3,4)]
title <- "Predicted Effect of 6+ Months Youth Unemployment by Age and Unemployment Rate"
title.color <- "Unemployment Rate"
filename <- "Images/Unemployment Rate.png"

ggplot(p,aes(x=age, y=coefficients, ymin=lci, ymax=uci, 
             color=factor(comparison), fill=factor(comparison))) +
  geom_segment(aes(x=0,xend=max(p$age),y=0,yend=0),colour="black") +
  geom_line(size=1) + geom_ribbon(alpha=0.15,colour = NA) +
  theme_minimal() + labs(title=title,x="Age",y="GHQ",
                         fill=title.color,color=title.color) +
  scale_x_continuous(breaks=x.breaks,labels=x.breaks+18,limits=c(0,42)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
  scale_fill_manual(values = alpha(color)) +
  scale_color_manual(values = alpha(color)) +
  theme(axis.text.x = element_text(size=12,color="#000000"),
        axis.text.y = element_text(size=12,color="#000000"),
        axis.title.x = element_text(size=12))



















p <- preds[preds$comparator=="0.NEET x 0.Modifier",]
title <- paste("Predicted Effect Relative to <6 Months NEET,",
               objs$gg.info[[modifier]]$title,"= 0")
x.title <- objs$gg.info[[modifier]]$x.title
color <- cbbPalette[6:7]
color.lbl <- c("6+ Months NEET","<6 Months NEET")
ggplot(p,aes(x=levels, y=beta, ymin=lci, ymax=uci, 
             color=factor(neet), fill=factor(neet))) +
  geom_segment(aes(x=0,xend=max(p$levels),y=0,yend=0),colour="black") +
  geom_line(size=1) + geom_ribbon(alpha=0.15,colour = NA) +
  theme_minimal() + 
  theme(legend.justification=c(1,0), legend.position=c(0.9,0.7)) +
  labs(title=title,x=x.title,y="") +
  scale_x_continuous(breaks= x.breaks) +
  scale_fill_manual(name="",values = alpha(color),labels=color.lbl) +
  scale_color_manual(name="",values = alpha(color),labels=color.lbl) +
  theme(axis.text.x = element_text(size=12,color="#000000"),
        axis.text.y = element_text(size=12,color="#000000"),
        axis.title.x = element_text(size=12))



ggplot(data=preds,aes(x=age,y=coefficients,ymin=lci,ymax=uci,color=unemployed,fill=unemployed)) +
  geom_line() +
  geom_ribbon(alpha=0.3)

ggplot(data=preds,aes(x=age,y=coefficients,ymin=lci,ymax=uci,color=unemrate,fill=unemrate)) +
  geom_line() +
  geom_ribbon(alpha=0.3)

























predsFun <- function(.) newdata%*%fixef(.) 
boots <- bootMer(models$all,FUN=predsFun,nsim=10)

pred <- newdata%*%fixef(models$all) 
pval <- diag(newdata %*% tcrossprod(vcov(models$all),newdata))

predict(models$all,newdata,re.form=NA)

x <- vcov(models$all)
y <- tcrossprod(vcov(models$all),newdata)
z <- newdata %*% tcrossprod(vcov(models$all),newdata)
a <- diag(newdata %*% tcrossprod(vcov(models$all),newdata))

newdata%*%fixef(models$all)

dimnames(newdata)
names(fixef(models$all))

x <- lm(GHQ_Likert ~ poly(Age_Y_C2,2),df)
summary(x)
newdata <- model.matrix(formula.fixed,df)[1:10,]
newdata[,] <- 0
newdata[,"Age_Y_C2"] <- 1:10
newdata[,"I(Age_Y_C2^2)"] <- (1:10)^2
newdata[,"I(Age_Y_C2^3)"] <- (1:10)^3


pred <- newdata%*%fixef(models$all) 
var <- diag(newdata %*% tcrossprod(vcov(models$all),newdata))
se <- sqrt(var)
# https://biologyforfun.wordpress.com/2015/06/17/confidence-intervals-for-prediction-in-glmms/

y <- glht(models$all,newdata)
z <- summary(y)

#########################################################################
#### OFFCUTS ####
coefs <- coef(summary(models$all))[,"Estimate"]
vcovs <- vcov(summary(models$all))







lin.com <- matrix(0,nrow=max(df$Age_Y_C2)+1,ncol=length(coefs))
dimnames(lin.com)[[2]] <- names(coefs)
lin.com[,"Age_Y_C2"] <- 0:max(df$Age_Y_C2)
lin.com[,"I(Age_Y_C2^2)"] <- (0:max(df$Age_Y_C2))^2
lin.com[,"I(Age_Y_C2^3)"] <- (0:max(df$Age_Y_C2))^3
preds <- glht(models$all,lin.com)

$test[c("coefficients","sigma","pvalues")]



model <- lm(GHQ_Likert ~ Age_Y_C2,df)
coefs <- coef(model)
lin.com <- matrix(0:1,nrow=1,ncol=length(coefs))
x <- glht(model,lin.com)
summary(x)
x<-summary(models$all)

xsummary(model)
coefs <- coef(summary(model))[,"Estimate"]
cols <- grep("Age_Y_C2",names(coefs))
curve(coefs[cols][1]*x+coefs[cols][2]*(x^2)+coefs[cols][3]*(x^3), 0, 42)



m1 = lmer(effect~duration+(1+duration|sites)+(1+duration|season), 
          data = dat1, REML = FALSE, 
          control = )



relgrad <- with(models$all@optinfo$derivs,solve(Hessian,gradient))
max(abs(relgrad))



model <- lmer(GHQ_Likert ~ Age_Y_C2 + I(Age_Y_C2^2) + (1|pidp), data = df[1:1000,])

mySumm2 <- function(.) {
  c(beta=fixef(.),sigma=sigma(.), sig01=sqrt(unlist(VarCorr(.))))
}
boots <- bootMer(model,mySumm2,nsim=100)




lin.com[1,2] <- 20
summary(glht(model,lin.com))

preds <- summary(glht(lm,lin.com))$test[c("coefficients","sigma","pvalues")] %>%
  as.data.frame() %>% dplyr::select(coefficients,sigma) %>%
  rbind(c(0,0),.)