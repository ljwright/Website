## 1. Download UK Wide Unemployment Rate
codes <- data.frame(
  code = c("LF2Q",paste0("YCN",LETTERS[3:14]),"ZSFB"),
  region = c("UK","North East","North West",
             "Yorkshire and the Humber","East Midlands",
             "West Midlands","East of England","London",
             "South East", "South West","England",
             "Wales","Scotland","Northern Ireland"),
  stringsAsFactors = FALSE
)
data <- data.frame(
  date = character(),value=character(),
  region = character(),stringsAsFactors = FALSE
)


## 2. Download Unemployment Rates
for (code in codes$code){
  path <- paste0("dataset/LMS/timeseries/",code,"/data")
  raw <- GET(url = "https://api.ons.gov.uk",path = path)
  df <- fromJSON(rawToChar(raw$content))$months[c("date","value")]
  df$Region <- codes$region[codes$code==code]
  
  data <- rbind(data,df)
}
write_dta(data,paste0(objs$paths$data,"Unemployment Rate.dta"))
rm(list=setdiff(ls(),"objs"))
